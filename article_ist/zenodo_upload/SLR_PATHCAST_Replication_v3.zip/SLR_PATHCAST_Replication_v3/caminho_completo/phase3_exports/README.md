# phase3_exports

Full ML-block bibliographic exports used in Phase 3 are omitted from this
Zenodo zip for size. Screening decisions derived from them are in
`../phase3_ML_*.csv` and `../phase3_snowball_iter*_screen.csv`.

To rebuild the export set, follow `../05_PROTOCOLO_BUSCA_ML_E_D1.md`.
